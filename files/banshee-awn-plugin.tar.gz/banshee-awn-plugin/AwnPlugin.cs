/***************************************************************************
 *  AwnPlugin.cs
 *
 *  Written by James Willcox <snorp@snorp.net>
 ****************************************************************************/

/*  THIS FILE IS LICENSED UNDER THE MIT LICENSE AS OUTLINED IMMEDIATELY BELOW: 
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a
 *  copy of this software and associated documentation files (the "Software"),  
 *  to deal in the Software without restriction, including without limitation  
 *  the rights to use, copy, modify, merge, publish, distribute, sublicense,  
 *  and/or sell copies of the Software, and to permit persons to whom the  
 *  Software is furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in 
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
 *  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 *  DEALINGS IN THE SOFTWARE. 
 */

using System;
using System.IO;
using Gtk;
using Mono.Unix;

using Banshee.Base;
using Banshee.Configuration;
using Banshee.MediaEngine;
using NDesk.DBus;

public static class PluginModuleEntry
{
    public static Type [] GetTypes()
    {
        return new Type [] {
            typeof(Banshee.Plugins.Awn.AwnPlugin)
        };
    }
}

namespace Banshee.Plugins.Awn
{
    [Interface ("com.google.code.Awn")]
    public interface IAvantWindowNavigator
    {
        void SetTaskIconByName (string app, string icon);
        void UnsetTaskIconByName (string app);
    }
    
    public class AwnPlugin : Banshee.Plugins.Plugin
    {
        private IAvantWindowNavigator awn;
            
        protected override string ConfigurationName { get { return "awn"; } }
        public override string DisplayName { get { return Catalog.GetString("Avant Window Navigator"); } }
	
        public override string Description {
            get {
                return Catalog.GetString ("Provides integration with Avant Window Navigator");
            }
        }

        public override string [] Authors {
            get {
                return new string [] {
                    "James Willcox"
                };
            }
        }

        protected override void PluginInitialize ()
        {
            awn = Bus.Session.GetObject<IAvantWindowNavigator> ("com.google.code.Awn",
                                                                new ObjectPath ("/com/google/code/Awn"));
            PlayerEngineCore.EventChanged += OnEventChanged;
        }

        protected override void PluginDispose()
        {
            UnsetIcon ();
            
        }

        private void OnEventChanged (object o, PlayerEngineEventArgs args)
        {
            switch (args.Event) {
            case PlayerEngineEvent.StartOfStream:
            case PlayerEngineEvent.EndOfStream:
                UnsetIcon ();
                SetIcon ();
                break;
            case PlayerEngineEvent.TrackInfoUpdated:
                SetIcon ();
                break;
            default:
                break;
            }
        }

        private void SetIcon ()
        {
            if (awn != null && PlayerEngineCore.CurrentTrack != null &&
                File.Exists (PlayerEngineCore.CurrentTrack.CoverArtFileName)) {

                awn.SetTaskIconByName ("banshee", PlayerEngineCore.CurrentTrack.CoverArtFileName);
            }
        }

        private void UnsetIcon ()
        {
            if (awn != null) {
                awn.UnsetTaskIconByName ("banshee");
            }
        }
        
        public static readonly SchemaEntry<bool> EnabledSchema = new SchemaEntry<bool> (
            "plugins.awn", "enabled",
            true,
            "Plugin enabled",
            "Multimedia Keys plugin enabled");
    }
}
