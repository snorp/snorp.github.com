
using System;

namespace DAAP {

    public class AuthenticationException : ApplicationException {

        public AuthenticationException (string msg) : base (msg) {
        }
    }
}
